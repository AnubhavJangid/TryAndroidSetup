package com.example.originalmarines.modal

import android.os.Parcel
import android.os.Parcelable
import java.io.Serializable

class HomeBannerModal() : Serializable {

    var banner_id: Int = 0
    var banner_name: String? = ""
    var banner_image: String? = ""
}
