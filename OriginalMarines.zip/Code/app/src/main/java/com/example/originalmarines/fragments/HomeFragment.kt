package com.example.originalmarines.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.ViewPager
import com.example.originalmarines.R
import com.example.originalmarines.adapter.HomeViewPagerAdapter
import com.example.originalmarines.base.BaseFragment
import com.example.originalmarines.modal.HomeBannerModal
import kotlinx.android.synthetic.main.fragment_home.*

/**
 * Created by Anubhav Jangid
 */
class HomeFragment : BaseFragment() {

    private var homeViewPagerAdapter : HomeViewPagerAdapter? = null
    private var homeBannerList : ArrayList<HomeBannerModal>? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bindUiViews()
    }

    private fun bindUiViews(){
        setViewPager()
    }

    private fun setViewPager(){
        homeBannerList = ArrayList()
        setViewPagerData()
        homeViewPagerAdapter = HomeViewPagerAdapter(homeBannerList!!, activity!!)
        viewPagerHome.adapter = homeViewPagerAdapter
        tabLayoutViewPager.setupWithViewPager(viewPagerHome)
        viewPagerHome.addOnPageChangeListener(viewPagerPageChangeListener)
    }

    private fun setViewPagerData(){
        val homeBannerModal = HomeBannerModal()
        homeBannerModal.banner_id = 1
        homeBannerModal.banner_name = "Name"
        homeBannerModal.banner_image = "https://images.pexels.com/photos/35188/child-childrens-baby-children-s.jpg?cs=srgb&dl=pexels-bess-hamiti-35188.jpg&fm=jpg"
        homeBannerList?.add(homeBannerModal)
        homeBannerModal.banner_id = 1
        homeBannerModal.banner_name = "Name"
        homeBannerModal.banner_image = "https://images.pexels.com/photos/35188/child-childrens-baby-children-s.jpg?cs=srgb&dl=pexels-bess-hamiti-35188.jpg&fm=jpg"
        homeBannerList?.add(homeBannerModal)
        homeBannerModal.banner_id = 1
        homeBannerModal.banner_name = "Name"
        homeBannerModal.banner_image = "https://images.pexels.com/photos/35188/child-childrens-baby-children-s.jpg?cs=srgb&dl=pexels-bess-hamiti-35188.jpg&fm=jpg"
        homeBannerList?.add(homeBannerModal)
        homeBannerModal.banner_id = 1
        homeBannerModal.banner_name = "Name"
        homeBannerModal.banner_image = "https://images.pexels.com/photos/35188/child-childrens-baby-children-s.jpg?cs=srgb&dl=pexels-bess-hamiti-35188.jpg&fm=jpg"
        homeBannerList?.add(homeBannerModal)
    }

    private var viewPagerPageChangeListener: ViewPager.OnPageChangeListener =
        object : ViewPager.OnPageChangeListener{
            override fun onPageScrollStateChanged(state: Int) {
                // your logic here
            }

            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int
            ) {
                // your logic here
            }

            override fun onPageSelected(position: Int) {
                // your logic here
                makeToast("Position$position")
            }
        }
}